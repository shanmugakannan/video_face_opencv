#ifndef SD_CXCORE_H_WRAPPER_HPP
#define SD_CXCORE_H_WRAPPER_HPP

#include <cxcore.h>

namespace flann {
    class Index {};
}

#include "cxcore_h_template_instantiations.hpp"

#endif

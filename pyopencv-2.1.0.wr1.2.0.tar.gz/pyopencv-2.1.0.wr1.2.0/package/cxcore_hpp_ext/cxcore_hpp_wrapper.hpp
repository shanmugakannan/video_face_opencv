#ifndef SD_CXCORE_HPP_WRAPPER_HPP
#define SD_CXCORE_HPP_WRAPPER_HPP

#include "opencv_headers.hpp"

#include "cxcore_hpp_template_instantiations.hpp"

#endif

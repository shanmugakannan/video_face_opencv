#ifndef SD_CXTYPES_H_WRAPPER_H
#define SD_CXTYPES_H_WRAPPER_H

#include <vector>

#include "opencv_headers.hpp"

#include "cxtypes_h_template_instantiations.hpp"


struct CvGenericHash {};

#endif

#ifndef SD_HIGHGUI_WRAPPER_H
#define SD_HIGHGUI_WRAPPER_H

#include "opencv_headers.hpp"

#include "highgui.h"

#include "highgui_template_instantiations.hpp"


#endif

#ifndef SD_OPENCV_WRAPPER_HPP
#define SD_OPENCV_WRAPPER_HPP

#include "sdopencv.hpp"

#include "sdopencv_template_instantiations.hpp"

#endif

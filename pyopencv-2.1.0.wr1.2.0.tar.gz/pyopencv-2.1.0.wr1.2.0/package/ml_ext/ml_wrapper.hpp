#ifndef SD_ML_WRAPPER_H
#define SD_ML_WRAPPER_H

#include "opencv_headers.hpp"

struct CvFileStorage {};

#include "ml.h"

#include "ml_template_instantiations.hpp"


#endif

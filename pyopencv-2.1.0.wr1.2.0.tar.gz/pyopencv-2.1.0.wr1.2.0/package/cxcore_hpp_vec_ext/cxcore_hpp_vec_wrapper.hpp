#ifndef SD_CXCORE_HPP_VEC_WRAPPER_HPP
#define SD_CXCORE_HPP_VEC_WRAPPER_HPP

#include "opencv_headers.hpp"

#include "cxcore_hpp_vec_template_instantiations.hpp"

#endif
